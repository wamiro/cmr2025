<?php

namespace App\Http\Controllers;

use App\Models\Document;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    public function index() {
        $documents = Document::latest()->paginate(10);
        return view('documents.index', compact('documents'));
    }

    public function create() {
        return view('documents.create');
    }

    public function store(Request $request) {
        $data = $request->validate([
            'titre' => 'required',
            'type' => 'nullable',
            'source' => 'nullable',
            'fichier' => 'nullable|file',
        ]);

        if ($request->hasFile('fichier')) {
            $data['fichier'] = $request->file('fichier')->store('documents', 'public');
        }

        Document::create($data);
        return redirect()->route('documents.index');
    }
}
