<?php

namespace App\Http\Controllers;

use App\Models\Candidat;
use Illuminate\Http\Request;

class CandidatController extends Controller
{
    public function index() {
        $candidats = Candidat::latest()->paginate(10);
        return view('candidats.index', compact('candidats'));
    }

    public function create() {
        return view('candidats.create');
    }

    public function store(Request $request) {
        $data = $request->validate([
            'nom' => 'required',
            'parti' => 'nullable',
            'biographie' => 'nullable',
            'photo' => 'nullable|image',
        ]);

        if ($request->hasFile('photo')) {
            $data['photo'] = $request->file('photo')->store('candidats', 'public');
        }

        Candidat::create($data);
        return redirect()->route('candidats.index');
    }
}
