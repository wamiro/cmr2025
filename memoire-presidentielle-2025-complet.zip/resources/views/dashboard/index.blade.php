@extends('layouts.app')

@section('content')
<div class="container">
  <h2>Tableau de bord - Mémoire Présidentielle 2025</h2>
  <div class="row mt-4">
    <div class="col-md-6"><a href="/candidats" class="btn btn-primary w-100">Gérer les Candidats</a></div>
    <div class="col-md-6"><a href="/documents" class="btn btn-secondary w-100">Gérer les Documents</a></div>
  </div>
</div>
@endsection
