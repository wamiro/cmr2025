<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CandidatController;
use App\Http\Controllers\DocumentController;

Route::get('/', function () {
    return view('welcome');
})->name('accueil');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard.index');
    })->name('dashboard');

    Route::resource('candidats', CandidatController::class);
    Route::resource('documents', DocumentController::class);
});

require __DIR__.'/auth.php';
